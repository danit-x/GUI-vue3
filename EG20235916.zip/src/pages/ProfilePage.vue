<script setup lang="ts">
import { computed } from "vue"
import { useRoute, useRouter } from "vue-router"
import { useAuthStore } from "../stores/authStore"
import { useCountryPreference } from "../composables/useCountryPreference"
import { ROUTES } from "../router/routes"
import { buildLoginLocation } from "../utils/loginRedirect"
import { formatPrice } from "../utils/formatPrice"
import { getOrdersForUser } from "../utils/orderHistory"

const auth = useAuthStore()
const route = useRoute()
const router = useRouter()
const { selectedCountry } = useCountryPreference()
const loginLocation = computed(() => buildLoginLocation(route.fullPath))

const initials = computed(() => {
  if (!auth.user) {
    return "VY"
  }

  return `${auth.user.firstName?.[0] || ""}${auth.user.lastName?.[0] || ""}`.toUpperCase()
})

const orderHistory = computed(() => getOrdersForUser(auth.user?.id))

function handleLogout() {
  auth.logout()
  router.push(ROUTES.home)
}
</script>

<template>
  <section class="vybe-page space-y-6 sm:space-y-8 md:space-y-8 lg:space-y-8">
    <div class="vybe-hero rounded-[2.4rem] p-5 sm:p-6 md:p-8">
      <div class="grid gap-5 sm:gap-6 md:gap-6 lg:grid-cols-[1.05fr_0.95fr] lg:items-end">
        <div class="space-y-2.5 sm:space-y-3 md:space-y-4">
          <p class="vybe-kicker text-[10px] sm:text-[11px]">Profile</p>
          <h1 class="vybe-display text-[clamp(2.5rem,7vw,5rem)] leading-[0.94]">
            Your account at a glance.
          </h1>
          <p class="max-w-2xl text-xs leading-6 text-[color:var(--muted)] sm:text-sm md:text-base md:leading-7">
            Review your basic account details and see the country preference selected from the navbar.
          </p>
        </div>

        <div class="grid grid-cols-2 gap-2.5 sm:gap-3 md:gap-3">
          <div class="vybe-stat">
            <p class="vybe-kicker text-[9px] sm:text-[10px]">Status</p>
            <p class="mt-2 sm:mt-3 text-lg sm:text-2xl text-[color:var(--text)]">{{ auth.isLoggedIn ? "Signed In" : "Guest" }}</p>
          </div>
          <div class="vybe-stat">
            <p class="vybe-kicker text-[9px] sm:text-[10px]">Country</p>
            <p class="mt-2 sm:mt-3 text-lg sm:text-2xl text-[color:var(--text)]">{{ selectedCountry }}</p>
          </div>
        </div>
      </div>
    </div>

    <div v-if="auth.isLoggedIn && auth.user" class="grid gap-5 sm:gap-6 md:gap-6 lg:grid-cols-[18rem_minmax(0,1fr)]">
      <aside class="vybe-panel rounded-[2rem] p-4 sm:p-5 md:p-6">
        <div class="flex flex-col items-center text-center">
          <div class="flex h-20 w-20 items-center justify-center rounded-full border border-[color:var(--line)] bg-[color:var(--bg-strong)] text-2xl text-[color:var(--text)] sm:h-24 sm:w-24 sm:text-3xl">
            {{ initials }}
          </div>
          <h2 class="vybe-display mt-3 sm:mt-4 text-2xl sm:text-3xl text-[color:var(--text)]">
            {{ auth.user.firstName }} {{ auth.user.lastName }}
          </h2>
          <p class="mt-1.5 sm:mt-2 text-xs text-[color:var(--muted)] sm:text-sm">@{{ auth.user.username }}</p>
          <button
            class="vybe-surface-link vybe-touch-target mt-5 inline-flex rounded-full px-5 py-2.5 text-xs uppercase tracking-[0.22em] sm:mt-6 sm:px-6 sm:py-3"
            type="button"
            @click="handleLogout"
          >
            Log Out
          </button>
        </div>
      </aside>

      <div class="space-y-5 sm:space-y-6">
        <div class="vybe-panel rounded-[2rem] p-4 sm:p-5 md:p-6 lg:p-8">
          <div class="grid gap-3 sm:gap-4 sm:grid-cols-2 md:gap-5">
            <div class="vybe-card rounded-[1.5rem] p-4 sm:p-5 md:p-6">
              <p class="vybe-kicker text-[9px] sm:text-[10px]">First name</p>
              <p class="mt-2 sm:mt-3 text-base sm:text-lg text-[color:var(--text)]">{{ auth.user.firstName }}</p>
            </div>
            <div class="vybe-card rounded-[1.5rem] p-4 sm:p-5 md:p-6">
              <p class="vybe-kicker text-[9px] sm:text-[10px]">Last name</p>
              <p class="mt-2 sm:mt-3 text-base sm:text-lg text-[color:var(--text)]">{{ auth.user.lastName }}</p>
            </div>
            <div class="vybe-card rounded-[1.5rem] p-4 sm:p-5 md:p-6">
              <p class="vybe-kicker text-[9px] sm:text-[10px]">Username</p>
              <p class="mt-2 sm:mt-3 text-base sm:text-lg text-[color:var(--text)]">{{ auth.user.username }}</p>
            </div>
            <div class="vybe-card rounded-[1.5rem] p-4 sm:p-5 md:p-6">
              <p class="vybe-kicker text-[9px] sm:text-[10px]">Email</p>
              <p class="mt-2 sm:mt-3 break-all text-base sm:text-lg text-[color:var(--text)]">{{ auth.user.email }}</p>
            </div>
          </div>
        </div>

        <div class="vybe-panel rounded-[2rem] p-4 sm:p-5 md:p-6 lg:p-8">
          <div class="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p class="vybe-kicker text-[10px] sm:text-[11px]">Orders</p>
              <h2 class="vybe-display mt-2 text-2xl sm:text-3xl text-[color:var(--text)]">Your order history.</h2>
            </div>
            <p class="text-xs uppercase tracking-[0.2em] text-[color:var(--muted)] sm:text-sm">
              {{ orderHistory.length }} {{ orderHistory.length === 1 ? "order" : "orders" }}
            </p>
          </div>

          <div v-if="orderHistory.length" class="mt-5 grid gap-4 sm:mt-6 sm:gap-5">
            <article
              v-for="order in orderHistory"
              :key="order.id"
              class="vybe-card rounded-[1.75rem] p-4 sm:p-5 md:p-6"
            >
              <div class="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                <div class="min-w-0">
                  <p class="vybe-kicker text-[9px] sm:text-[10px]">Order {{ order.id }}</p>
                  <h3 class="mt-2 text-xl font-semibold text-[color:var(--text)] sm:text-2xl">
                    {{ order.status }}
                  </h3>
                  <p class="mt-2 text-xs leading-6 text-[color:var(--muted)] sm:text-sm">
                    {{ new Date(order.placedAt).toLocaleString() }}
                  </p>
                  <p class="mt-2 break-words text-xs leading-6 text-[color:var(--muted)] sm:text-sm">
                    {{ order.paymentMethod.label }} | {{ order.paymentMethod.detail }}
                  </p>
                </div>

                <div class="grid grid-cols-2 gap-2.5 sm:gap-3">
                  <div class="rounded-[1.25rem] border border-[color:var(--line)] px-4 py-3">
                    <p class="text-[10px] uppercase tracking-[0.2em] text-[color:var(--muted)]">Items</p>
                    <p class="mt-2 text-lg text-[color:var(--text)]">{{ order.itemCount }}</p>
                  </div>
                  <div class="rounded-[1.25rem] border border-[color:var(--line)] px-4 py-3">
                    <p class="text-[10px] uppercase tracking-[0.2em] text-[color:var(--muted)]">Total</p>
                    <p class="mt-2 text-lg text-[color:var(--accent)]">{{ formatPrice(order.totalPrice) }}</p>
                  </div>
                </div>
              </div>

              <div class="mt-4 grid gap-2.5 sm:mt-5">
                <div
                  v-for="step in order.progressSteps"
                  :key="`${order.id}-${step.label}`"
                  class="rounded-[1.35rem] border p-3 sm:p-4"
                  :class="step.state === 'complete'
                    ? 'vybe-status-complete'
                    : step.state === 'current'
                      ? 'vybe-status-current'
                      : 'vybe-status-upcoming'"
                >
                  <div class="flex items-start justify-between gap-3">
                    <div>
                      <p class="text-[10px] uppercase tracking-[0.2em] text-[color:var(--muted)] sm:text-[11px]">
                        {{ step.state === "current" ? "Current step" : step.state === "complete" ? "Done" : "Upcoming" }}
                      </p>
                      <p class="mt-1 text-sm font-semibold text-[color:var(--text)] sm:text-base">{{ step.label }}</p>
                      <p class="mt-1 text-xs leading-6 text-[color:var(--muted)] sm:text-sm">{{ step.detail }}</p>
                    </div>
                    <span
                      class="mt-1 inline-flex h-3.5 w-3.5 shrink-0 rounded-full"
                      :class="step.state === 'complete'
                        ? 'vybe-status-dot-complete'
                        : step.state === 'current'
                          ? 'vybe-status-dot-current'
                          : 'bg-[color:var(--line)]'"
                    />
                  </div>
                </div>
              </div>

              <div class="mt-4 grid gap-3 sm:mt-5">
                <div
                  v-for="item in order.items"
                  :key="`${order.id}-${item.id}`"
                  class="flex items-center justify-between gap-3 rounded-[1.25rem] border border-[color:var(--line)] px-4 py-3"
                >
                  <div class="min-w-0">
                    <p class="text-sm font-semibold text-[color:var(--text)] sm:text-base">{{ item.title }}</p>
                    <p class="mt-1 text-xs text-[color:var(--muted)] sm:text-sm">
                      {{ formatPrice(item.price) }} x {{ item.quantity }}
                    </p>
                  </div>
                  <p class="text-sm text-[color:var(--accent)] sm:text-base">{{ formatPrice(item.price * item.quantity) }}</p>
                </div>
              </div>
            </article>
          </div>

          <div v-else class="vybe-empty mt-5 px-4 py-10 sm:mt-6 sm:px-6 sm:py-12">
            <p class="vybe-display text-2xl sm:text-3xl text-[color:var(--text)]">No past orders yet.</p>
            <p class="mx-auto mt-2 max-w-xl text-xs leading-6 text-[color:var(--muted)] sm:text-sm sm:leading-7">
              Place an order and it will stay here so you can revisit the timeline and payment method later.
            </p>
          </div>
        </div>
      </div>
    </div>

    <div v-else class="vybe-empty px-4 py-10 sm:px-6 sm:py-14 md:px-8">
      <p class="vybe-display text-2xl sm:text-3xl md:text-4xl text-[color:var(--text)]">Please log in to view your profile.</p>
      <p class="mx-auto mt-2 sm:mt-3 max-w-xl text-xs leading-6 text-[color:var(--muted)] sm:text-sm sm:leading-7 md:text-base md:leading-8">
        Your account details are only available after signing in.
      </p>
      <div class="mt-4 sm:mt-6 flex flex-col items-center justify-center gap-2.5 sm:flex-row sm:gap-3">
        <RouterLink :to="loginLocation" class="vybe-button vybe-touch-target rounded-full px-5 py-2.5 text-xs uppercase tracking-[0.22em] sm:px-6 sm:py-3 sm:text-sm">
          Log In
        </RouterLink>
        <RouterLink :to="ROUTES.signup" class="vybe-surface-link vybe-touch-target rounded-full px-5 py-2.5 text-xs uppercase tracking-[0.22em] sm:px-6 sm:py-3 sm:text-sm">
          Create Account
        </RouterLink>
      </div>
    </div>
  </section>
</template>
